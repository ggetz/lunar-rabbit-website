---
layout: post
title: "RPI GameFest 2016"
date: 2016-05-01 02:07:45
categories: news
tags: [Starbright]
author: Laura Mo
---

{% assign base = '' %}
{% assign depth = page.url | split: '/' | size | minus: 1 %}
{% if    depth == 1 %}{% assign base = '.' %}
{% elsif depth == 2 %}{% assign base = '..' %}
{% elsif depth == 3 %}{% assign base = '../..' %}
{% elsif depth == 4 %}{% assign base = '../../..' %}{% endif %}

We went to the GameFest 2016 at Rensselaer Polytechnic Institute on Saturday and we're happy to announce that Starbright won a prize for procedurally generated content!

![](http://lunarrabbit.com/img/posts/StarbrightRPI/Win.png)

There were a lot of impressive games this year, so it's a great honor that Starbright managed to get noticed!